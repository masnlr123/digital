<!--
  Copyright 2018 Google LLC

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('contents.download-report-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt-2">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <?php $__currentLoopData = $selectedFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col"><?php echo e($field); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $reportResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($index + 1); ?></th>
                    <?php $__currentLoopData = $row['@attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cellValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td> <?php echo e($cellValue); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr class="text-center"><td colspan="<?php echo e(count($selectedFields) + 1); ?>">
                        <strong>No data for this query.</strong></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($reportResults->links()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\google\laravel_ads2\resources\views/report-results.blade.php ENDPATH**/ ?>