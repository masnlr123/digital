
        <form action="<?php echo e(url('download-report')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" class="form-check-input" id="impressions" name="impressions" value="Impressions">
            <input type="hidden" class="form-check-input" id="clicks" name="clicks" value="Clicks">
            <input type="hidden" class="form-check-input" id="ctr" name="ctr" value="Ctr">
            <input type="hidden" class="form-check-input" id="cost" name="cost" value="Cost">
            <input type="hidden" class="form-check-input" id="conversions" name="conversions" value="Conversions">
            <input type="hidden" class="form-check-input" id="ConversionRate" name="ConversionRate" value="ConversionRate">
            <input type="hidden" class="form-check-input" id="CostPerConversion" name="CostPerConversion" value="CostPerConversion">
            <input type="hidden" class="form-check-input" id="SpeedScore" name="SpeedScore" value="SpeedScore">
            <input type="hidden" class="form-check-input" id="ValuePerConversion" name="ValuePerConversion" value="ValuePerConversion">
            <input type="hidden" class="form-check-input" id="VideoViewRate" name="VideoViewRate" value="VideoViewRate">
            <input type="hidden" class="form-check-input" id="VideoViews" name="VideoViews" value="VideoViews">
            <input type="hidden" class="form-check-input" id="crossDeviceConversions" name="crossDeviceConversions" value="CrossDeviceConversions">
            <div class="form-group row">
                <div class="col-sm-2">
                    <select class="form-control" id="clientCustomerId" name="clientCustomerId" required>
                        <option value="">Choose one Account</option>
                        <option value="584-012-3898">Eternity</option>
                        <option value="200-057-9858">Siruseri</option>
                        <option value="193-263-3184">Padur</option>
                        <option value="139-367-7531">Jubilee Residences</option>
                        <option value="927-598-0580">Humming Gardens</option>
                        <option value="249-340-6137">AGR Account - Agency</option>
                        <option value="829-584-8078">Alliance- Orchid Springss</option>
                        <option value="584-012-3898">Eternity</option>
                        <option value="139-043-4719">Galleria Residences</option>
                        <option value="927-598-0580">Humming Gardens</option>
                        <option value="775-701-7141">Hyderabad - Ameenpur</option>
                        <option value="489-090-8172">Jasmine Springs</option>
                        <option value="139-367-7531">Jubilee Residences</option>
                        <option value="193-263-3184">Padur</option>
                        <option value="200-057-9858">Siruseri</option>
                        <option value="856-834-3141">T-Sai</option>
                        <option value="602-632-8546">Urbanrise Projects</option>
                        <option value="331-738-4609">Villa Belvedere</option>
                    </select>
                </div>
                <div class="col-sm-4">
                    <select class="form-control" id="reportType" name="reportType" required>
                        <option selected>LANDING_PAGE_REPORT</option>
                        <option>CAMPAIGN_PERFORMANCE_REPORT</option>
                        <option>ADGROUP_PERFORMANCE_REPORT</option>
                        <option>AD_PERFORMANCE_REPORT</option>
                        <option>ACCOUNT_PERFORMANCE_REPORT</option>
                    </select>
                </div>
                <div class="col-sm-2">
                    <select class="form-control" id="reportRange" name="reportRange" required>
                        <option selected>YESTERDAY</option>
                        <option>LAST_7_DAYS</option>
                        <option>LAST_WEEK</option>
                        <option>LAST_MONTH</option>
                    </select>
                </div>
                <label for="entriesPerPage" class="col-sm-1 col-form-label">Per page</label>
                <div class="col-sm-1">
                    <select class="form-control" id="entriesPerPage" name="entriesPerPage" required>
                        <option selected>20</option>
                        <option>50</option>
                        <option>100</option>
                        <option>200</option>
                    </select>
                </div>
                <div class="col-sm-1">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </form>

<?php /**PATH D:\server\htdocs\google\laravel_ads2\resources\views/contents/download-report-form.blade.php ENDPATH**/ ?>