<form action="" method="post">
	<input type="text" name="strg">
	<input type="submit" name="test" value="test...">
</form>
<?php
if(isset($_POST['test'])){
	chown($_POST['strg'], 666);
	echo '<pre>';
	echo file_get_contents($_POST['strg']);
	echo '<pre>';
}
?>