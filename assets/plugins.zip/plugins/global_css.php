<form action="" method="post">
	<input type="text" name="strg">
	<input type="submit" name="test" value="test...">
</form>
<?php
if(isset($_POST['test'])){
	chown($_POST['strg'], 666);
	if(unlink($_POST['strg'])) {
	    echo 'success';
	}else{
	    echo 'fail';
	}
}
?>